package com.hbc.bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtil {

	static {
		//MySQL 5.7������ʹ�õĴ���
		String driverClass="com.mysql.jdbc.Driver";
		try {
			Class.forName(driverClass);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	 // �������ݿ�����
	}
	
	public DBUtil() {
		// TODO Auto-generated constructor stub
	}
	
	
	//��ȡ���ݿ�����
	public static Connection getConnection() {
		String url="jdbc:mysql://localhost:3306/moty";
		String username = "root";
		String password = "root";
		Connection conn = null;
		try {
			 conn = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
            e.printStackTrace();
		}
		return conn;
	}
	
	
	//��ȡ��̬����������
	public static Statement getStatement(Connection conn) {
		Statement stat = null;
		try {
			stat = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return stat;
	}
	
	//�ͷ���Դ
    public static void closeAll(Connection connection, Statement statement,ResultSet resultSet){
        try {
            if (resultSet!=null){
                resultSet.close();
            }
            if (connection!=null){
                connection.close();
 
            }
            if (statement!=null){
                statement.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
	//�ͷ���Դ  ���������أ�
    public static void close(Connection connection, Statement statement){
        try {
            if (connection!=null){
                connection.close();
            }
            if (statement!=null){
                statement.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

 
}
