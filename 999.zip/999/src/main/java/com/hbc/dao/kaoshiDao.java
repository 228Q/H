package com.hbc.dao;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.*;

import com.hbc.bean.DBUtil;
import com.hbc.bean.kaoshi;

 

public class kaoshiDao {

	public kaoshiDao() {
		// TODO Auto-generated constructor stub
	}
	
	public List getAll() {
		List list = null;
		Connection conn = null;
		Statement stat = null;
		ResultSet rs = null;
		conn = DBUtil.getConnection();
		stat = DBUtil.getStatement(conn);
		
		stat.executeQuery( " select * from tb_kaoshi");
		
		 rs = stat.executeQuery(sql);
		
		
		
		
		
		return list;
		
			
	}
}

	
	