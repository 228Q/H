package com.hbc.bean;

public class kaoshi {

	private int id;
	private String name;
	private String gender;
	private String phone;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	public kaoshi(int id, String name, String gender, String phone) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.phone = phone;
	}
	
	public kaoshi() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
