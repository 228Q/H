package com.hbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hbc.bean.DBUtil;
import com.hbc.bean.StuBean;

 

public class StuDAO {

	public StuDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public List queryAll() {
		List list = new ArrayList();
		Connection conn = DBUtil.getConnection();
		Statement stat = DBUtil.getStatement(conn);	
		ResultSet rs = null;
		try {
			rs = stat.executeQuery("select * from tb_stu");
			StuBean stu = null;
			while(rs.next()) {
				stu = new StuBean();
				stu.setStuId(rs.getInt(1)); 
				stu.setStuName(rs.getString(2));
				stu.setStuSex(rs.getString(3));
				stu.setStuPhone(rs.getString(4));
				list.add(stu);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, stat, rs);
		}
		return list;
	}
	
	public void deleteById(int stuId) {
		List list = new ArrayList();
		Connection conn = DBUtil.getConnection();
		Statement stat = DBUtil.getStatement(conn);	
		try {
			int rn = stat.executeUpdate("delete from tb_stu where stuId="+stuId);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, stat);
		}
	}
	
	public void addStu(StuBean stu) {
		Connection conn = DBUtil.getConnection();
		PreparedStatement stat = null;
		String sql = "insert into tb_stu(stuId,stuName,stuSex,stuPhone) values(?,?,?,?)";
		try {
			stat = conn.prepareStatement(sql);
			stat.setInt(1, stu.getStuId());
			stat.setString(2, stu.getStuName());
			stat.setString(3, stu.getStuSex());
			stat.setString(4, stu.getStuPhone());
			int rtn = stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, stat);
		}
	}
	
	public StuBean selectById(int stuId) {
		StuBean stu = new StuBean();
		Connection conn = DBUtil.getConnection();
		Statement stat = DBUtil.getStatement(conn);	
		ResultSet rs = null;
		try {
			rs = stat.executeQuery("select * from tb_stu where stuId="+stuId);
			while(rs.next()) {
				stu.setStuId(rs.getInt(1)); 
				stu.setStuName(rs.getString(2));
				stu.setStuSex(rs.getString(3));
				stu.setStuPhone(rs.getString(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.closeAll(conn, stat,rs);
		}
		return stu;
	}
	
	
	public void updateStu(StuBean stu) {
		Connection conn = DBUtil.getConnection();
		PreparedStatement stat = null;
		String sql = "update tb_stu set stuName=?,stuSex=?,stuPhone=? where stuId=?";
		try {
			stat = conn.prepareStatement(sql);
			stat.setString(1, stu.getStuName());
			stat.setString(2, stu.getStuSex());
			stat.setString(3, stu.getStuPhone());
			stat.setInt(4, stu.getStuId());
			int rtn = stat.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			DBUtil.close(conn, stat);
		}
	}

}
